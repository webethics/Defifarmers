import { useState, useEffect } from 'react';
import { experimentalStyled as styled } from '@material-ui/core/styles';
import { Grid, Container, Box, Button, Typography } from '@material-ui/core';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import { Link as RouterLink } from 'react-router-dom';
import { createBrowserHistory } from 'history';
// redux
import { useSelector } from '../../redux/store';
// components
import Page from '../../components/Page';
import uniqueId from 'utils/uniqueId';
// @types
import { ProductState } from '../../@types/products';
import { isEqual } from 'lodash';
// date fucntion
import { add } from 'date-fns';
// lottie
import Lottie from 'react-lottie';
import animationData from '../../lotties/62761-walking-pothos.json';
import { Player } from '@lottiefiles/react-lottie-player';
import CollectionCard from './collectionCard';
import { useTreedefiFarmers } from 'hooks/useContract';
import { useWallet } from '@binance-chain/bsc-use-wallet';
import RarityRankingBox from '../../components/RarityRankingBox';
import axios from 'axios';
import Skeleton from '@mui/material/Skeleton';
// ----------------------------------------------------------------------

const RootStyle = styled(Page)(({ theme }) => ({
  paddingTop: theme.spacing(8),
  [theme.breakpoints.up('md')]: {
    paddingTop: theme.spacing(11),
  },
}));

// ----------------------------------------------------------------------

const defaultOptions = {
  loop: true,
  autoplay: true,
  animationData: animationData,
  rendererSettings: {
    preserveAspectRatio: 'xMidYMid slice',
  },
};

// ----------------------------------------------------------------------

const MyCollection = () => {
  const history = createBrowserHistory();
  const linkTo = (id: string) => `/sell/${id}`;
  const linkToDetails = (id: string) => `/tree/${id}`;
  const [open, setOpen] = useState(false);
  const { account } = useWallet();
  const [treeData, setTreeData] = useState<any>();
  const [myCollection, setMyCollection] = useState([]);
  const farmerContract = useTreedefiFarmers();
  const [loading, setLoading] = useState(true);
  const [indexLength, setIndex] = useState(0);
  const ENDPOINT = process.env.REACT_APP_API;
  let b = [];
  useEffect(() => {
    const getData = async () => {
      let a = [];
      const indexToken = await farmerContract.methods.balanceOf(account).call();
      setIndex(indexToken);
      if (indexToken == 0) {
        setLoading(false);
      }
      for (let i = 0; i < indexToken; i++) {
        const tokenId = await farmerContract.methods
          .tokenOfOwnerByIndex(account, i)
          .call();
        const response = await axios.get(ENDPOINT + 'getFarmerData/' + tokenId);
        a.push(response.data.data);
        if (a.length == indexToken) {
          setMyCollection([...a]);
          setLoading(false);
        }
      }
    };
    if (account) {
      setLoading(true);
      setMyCollection([]);
      getData();
    } else {
      setLoading(false);
    }
  }, [account]);

  return (
    <RootStyle title='Treedefi - My Collection'>
      <Container maxWidth='lg'>
        <Grid container spacing={3}>
          <Grid item xs={12} mb={4}>
            <Box
              component='div'
              sx={{ display: 'flex' }}
              alignItems='center'
              className='d_b_575'
            >
              <Button
                className='back_ic back_ic_v2'
                onClick={() => history.back()}
              >
                <ChevronLeftIcon sx={{ fontSize: 20, lineHeight: '14px' }} />
                <Typography fontWeight={300} fontSize={16} sx={{ mt: 0 }}>
                  Back
                </Typography>
              </Button>
              <Typography
                variant='h4'
                component='h2'
                fontSize={{ lg: 32, xs: 24 }}
                fontWeight={600}
                sx={{ mr: 2 }}
              >
                My Farmer NFTs
              </Typography>
            </Box>
          </Grid>
          {/* Iteme */}

          {/* <Grid item xs={12} sm={6} md={4} lg={3} mb={3}>
            <RarityRankingBox />
          </Grid> */}

          {myCollection && myCollection.length > 0 && !loading && (
            <>
              {myCollection.map((farmer, index) => {
                return (
                  <Grid item xs={12} sm={6} md={4} lg={3} mb={3} key={index}>
                    <RarityRankingBox farmerData={farmer} />
                  </Grid>
                );
              })}
            </>
          )}

          {loading &&
            [...Array(4)].map((e, index) => (
              <Grid item xs={12} sm={6} md={4} lg={3} mb={3} key={index}>
                <Box className='farmer_box'>
                  <Skeleton variant='rectangular' height={300} />
                  <Box className='skltnpddng'>
                    <Skeleton variant='text' height={50} />
                    <Skeleton variant='text' height={20} />
                    <Skeleton variant='text' height={20} />
                    <Skeleton variant='text' height={20} />
                    <Skeleton variant='text' height={20} />
                    <Skeleton variant='text' height={20} />
                  </Box>
                </Box>
              </Grid>
            ))}

          {/* for spacing */}
          <Grid item xs={12} mb={5}>
            {myCollection && myCollection.length === 0 && !loading && (
              <div style={{ textAlign: 'center' }}>
                <Lottie options={defaultOptions} height={300} width={300} />
                <div>No My Farmer NFT found</div>
              </div>
            )}
          </Grid>
        </Grid>
      </Container>
    </RootStyle>
  );
};

export default MyCollection;
