import React, { useState, useEffect } from 'react';
import {
  Grid,
  Box,
  Container,
  Typography,
  Stack,
  Button,
} from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Element } from 'react-scroll';
// import AOS from 'aos';
import { Link } from 'react-scroll';
import { useWallet } from '@binance-chain/bsc-use-wallet';
import { useMysteryBoxAvax } from 'hooks/useContract';
import { useSnackbar } from 'notistack';
import LinearProgress from '@material-ui/core/LinearProgress';
import RarityRankingDemo from './RarityRankingDemo';

export default function BringingFarmars() {
  // AOS.init();
  const [count, setCount] = useState(0);
  const { account } = useWallet();
  const mystryBoxContract = useMysteryBoxAvax();
  const [Qty, setQty] = useState(0);
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();
  const [loading, setLoading] = useState(false);
  const [sold, setSold] = useState(0);
  const [price, setPrice] = useState(0);
  const [total, setTotal] = useState(0);

  function handlePlus() {
    if (count < Qty) {
      setCount(count + 1);
    }
  }

  function handleMinus() {
    if (count > 0) {
      setCount(count - 1);
    }
  }

  function handleValueChange(e) {
    const x = Number(e.target.value);

    if (isNaN(x) || x < 1 || x > Qty) {
    } else {
      setCount(x);
    }
    console.log(x);
  }

  const SubmitQty = async (e) => {
    if (account) {
      setLoading(true);
      let snackKey;

      await mystryBoxContract.methods
        .mint(count)
        .send({
          from: account,
          value: price * count,
        })
        .once('transactionHash', (transactionHash) => {
          snackKey = enqueueSnackbar('Miniting is in Progress', {
            variant: 'info',
            preventDuplicate: true,
            persist: true,
          });
        })
        .once('confirmation', (confirmation) => {
          closeSnackbar(snackKey);
          setLoading(false);
          enqueueSnackbar('Minted Successfully', {
            variant: 'info',
          });
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        })
        .on('error', (error) => {
          closeSnackbar(snackKey);

          setLoading(false);
          enqueueSnackbar('Error while Minting', {
            variant: 'error',
          });
        });
      e.preventDefault();
    } else {
      alert('Please Connect Wallet First');
    }
  };

  useEffect(() => {
    const getData = async () => {
      const itemSold = await mystryBoxContract.methods.itemsSold().call();
      setSold(itemSold);
      const lastid = await mystryBoxContract.methods.lastId().call();
      setTotal(lastid);
      const dailyLimit = await mystryBoxContract.methods.dailyLimit().call();

      const priceValue = await mystryBoxContract.methods.price().call();
      setPrice(priceValue);

      if (account) {
        const currentDay = await mystryBoxContract.methods.currentDay().call();
        const finalLimit = await mystryBoxContract.methods
          .dailyPurchase(account, currentDay)
          .call();
        setQty(dailyLimit - finalLimit);
      } else {
        setQty(dailyLimit);
      }
    };

    getData();
  }, [account]);

  return (
    <>
      <Box className='brngng_bnr_prnt'>
        <Box
          component='img'
          src='/static/images/banner_img.jpg'
          className='w-100'
          alt=''
        />
        <Box className='bnr_cntnt'>
          <Container maxWidth='lg'>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography component='h2' className='def_h'>
                  Bringing DeFi Farmers <br />
                  to the AVAX Community
                </Typography>
                <Box className='avx_bxc'>
                  <Link to='MintSc' smooth={true} duration={500}>
                    <Button
                      variant='contained'
                      color='secondary'
                      startIcon={
                        <Box
                          component='img'
                          src='/static/images/nertwork01.svg'
                          alt=''
                        />
                      }
                    >
                      Mint
                    </Button>
                  </Link>
                  {/* <Button
                    variant='contained'
                    color='secondary'
                    startIcon={
                      <Box
                        component='img'
                        src='/static/images/network02.png'
                        alt=''
                      />
                    }
                  >
                    Use BSC Network
                  </Button> */}
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Box>
      <Element name='FeaturesSc'>
        <Box className='abt_farmer'>
          <Container maxWidth='lg'>
            <Grid container spacing={3} alignItems={'center'}>
              <Grid item md={5}>
                <Box
                  className='tdimg_prnt'
                  // data-aos='fade-left'
                  // data-aos-duration='2000'
                >
                  <Box
                    component='img'
                    src='/static/images/multiplefarmers.gif'
                    alt=''
                  />
                </Box>
              </Grid>
              <Grid item md={7}>
                <Box
                  className='td_contant '
                  // data-aos='fade-up'
                  // data-aos-duration='1500'
                >
                  <Typography component='h2' className='def_h'>
                    DeFi Farmers
                  </Typography>
                  <Typography className='def_p '>
                    DeFi Farmers consists of 9,500 randomly generated
                    ecofriendly NFT Farmers living on the Avalanche network.
                    DeFi Farmers can be found with a variety of different
                    colours, outfits, and faces but no two Farmers are alike.
                    Each Farmers brings their own style with unique hats, hair,
                    clothing and farming tools from a total of 57 different
                    attributes!
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Element>
      <Element name='MintSc'>
        <Box className='becom_far'>
          <Box
            component='img'
            src='/static/images/bottom_img_01.png'
            alt=''
            className='top_img'
          />
          <Container maxWidth='lg'>
            <Grid container spacing={3}>
              <Grid item xs={6} md={3} className='fr_ordr tx_alin'>
                <Box
                  className='farmer_man_img'
                  // data-aos='fade-down'
                  // data-aos-duration='3500'
                >
                  <Box
                    component='img'
                    src='/static/images/farmer_img_1.png'
                    alt=''
                    className='farmer_img_01'
                  />
                  <Box
                    component='img'
                    src='/static/images/dot_img_01.svg'
                    alt=''
                    className='dot_img_01'
                  />
                </Box>
              </Grid>
              <Grid item xs={12} md={6}>
                <Box
                  className='becm_fr'
                  // data-aos='flip-left'
                  // data-aos-duration='4500'
                >
                  <Typography component='h2' className='def_h'>
                    Become a Farmer
                  </Typography>
                  <Typography>
                    Minting event will be announced on December, 23th
                  </Typography>
                  <Box className='counterDisplay'>
                    <Box className='qntt_box'>
                      <Button onClick={handleMinus}>-</Button>
                      <input
                        type='text'
                        min='0'
                        value={count}
                        onClick={() => setCount(0)}
                        onChange={handleValueChange}
                      />
                      <Button onClick={handlePlus} className='qnttbtnrgt'>
                        +
                      </Button>
                    </Box>
                    <Button className='AddBtn' onClick={SubmitQty}>
                      FARM IN!
                    </Button>
                  </Box>
                  <Typography className='qntt_btntxt'>
                    <span />
                    {price / 1e18} AVAX / Farmer
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={6} md={3} className='tx_alin'>
                <Box
                  className='farmer_man_img'
                  // data-aos='fade-down'
                  // data-aos-duration='3500'
                >
                  <Box
                    component='img'
                    src='/static/images/farmer_img_02.png'
                    alt=''
                    className='farmer_img_02'
                  />
                  <Box
                    component='img'
                    src='/static/images/dot_02.svg'
                    alt=''
                    className='dot_img_02'
                  />
                </Box>
              </Grid>
            </Grid>
          </Container>
          <Box
            component='img'
            src='/static/images/bottom_img_02.png'
            alt=''
            className='bottom_img'
          />
        </Box>
      </Element>

      <Box className='abt_farmer about_td_main'>
        <Container maxWidth='lg'>
          <Grid container spacing={3} alignItems={'center'}>
            <Grid item md={6}>
              <Box
                className='td_contant'
                // data-aos='fade-right'
                // data-aos-duration='2500'
              >
                <Typography component='h2' className='def_h'>
                  About Treedefi
                </Typography>
                <Typography className='def_p '>
                  <a href='https://treedefi.com'>Treedefi</a> allows investors
                  to have a real world impact, and offers them the opportunity
                  to offset their CO2 footprint through NFTrees, NFTs backed by
                  real planted trees around the world.
                </Typography>
              </Box>
            </Grid>
            <Grid item md={6}>
              <Box
                className='tdimg_prnt abt_td_pddngh'
                // data-aos='fade-left'
                // data-aos-duration='2500'
              >
                <object
                  type='image/svg+xml'
                  className='animtin_imgs'
                  data='/static/images/tree_farm.svg'
                  aria-label='tree_farm'
                />
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
      <Box className='tockenomics_bg_main'>
        <Box
          component='img'
          src='/static/images/tocknomics_img.png'
          alt=''
          // data-aos='flip-left'
          // data-aos-duration='2500'
        />
        <Box
          className='three_p'
          // data-aos='zoom-in'
          // data-aos-duration='1500'
        >
          <Typography component='h2' className='def_h'>
            Tokenomics
          </Typography>
          <Typography className='def_p '>
            Our Farmers has a reflectionary minting system that earns farmers
            holders AVAX!
          </Typography>
          <Typography className='def_p '>
            This means that 15% of every minting fee is reflected back to
            existing Farmers holders and can be claimed at any time!
          </Typography>
          <Typography className='def_p '>
            The rewards don't stop when minting is complete! In our marketplace
            original minters of Farmers earn 1% royalties each time their
            Farmers is resold and 3% of each sale is redistributed between all
            Farmers holders.
          </Typography>
        </Box>
      </Box>
      {/* <Box className='abt_farmer'>
        <Container maxWidth='lg'>
          <Grid container spacing={3} alignItems={'center'}>
            <Grid item md={5}>
              <Box className='tdimg_prnt'>
                <Box component='img' src='/static/images/reritty.png' alt='' />
              </Box>
            </Grid>
            <Grid item md={7}>
              <Box className='td_contant'>
                <Typography component='h2' className='def_h'>
                  Rarity Ranking
                </Typography>
                <Typography className='def_p '>
                  At Treedefi we don't have any dress codes, every Farmer is
                  welcome! That said, some Farmers have more style than others.
                </Typography>
                <Typography className='def_p '>
                  Farmers are scored on a scale of 3 to 13 points. The ranking
                  and background color of your Farmer is determined by the total
                  score of all attribute scores. Rarer items or features like an
                  VR viewer will score higher than common items like a shovel.
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box> */}
       <Box className='abt_farmer about_td_main'>
        <Container maxWidth='lg'>
          <Grid container spacing={3} alignItems={'center'}>
            <Grid item md={4}>
              <Box
                className='tdimg_prnt img_canter'
                // data-aos='fade-left'
                // data-aos-duration='2500'
              >
                <Box component="img" src="/static/images/tocknomics_img.png" />
                   {/* <object
                    type='image/svg+xml'
                    className='animtin_imgs'
                    data='/static/images/tree_farm.svg'
                    aria-label='tree_farm'
                  /> */}
              </Box>
            </Grid>
            <Grid item md={8}>
              <Box
                  className='td_contant'
                  // data-aos='fade-right'
                  // data-aos-duration='2500'
                >
                  <Typography component='h2' className='def_h'>
                  Discount for treedefi Holders
                  </Typography>
                  <Typography className='def_p '>
                      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Blanditiis exercitationem dolorem excepturi. Quaerat dolorum quos natus, facilis sed illum iste delectus ea praesentium id exercitationem, nostrum inventore a esse. Officiis voluptates facilis voluptate dolorem corrupti sit reiciendis, quia reprehenderit molestias.
                  </Typography>
                </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
      <Box className='abt_farmer about_td_main about_bg_01 '>
        <Container maxWidth='lg'>
          <Grid container spacing={3} alignItems={'center'}>
            <Grid item md={6}>
              <Box
                className='td_contant abt_h2_1'
                // data-aos='zoom-in-right'
                // data-aos-duration='2500'
              >
                <Typography component='h2' className='def_h'>
                  About Ecogamefi
                </Typography>
                <Typography className='def_p '>
                  Ecogamefi is the next trend of Ecofriendly defi project in the
                  gaming industry. Treedefi’s aim is to bring reality into the
                  virtual world by giving the opportunity to own real trees
                  while playing games and giving a sustainable impact.
                </Typography>
              </Box>
            </Grid>
            <Grid item md={6}>
              <Box
                className='tdimg_prnt abt_td_pddngh about_two_1'
                // data-aos='zoom-in-left'
                // data-aos-duration='2500'
              >
                <object
                  type='image/svg+xml'
                  className='animtin_imgs'
                  data='/static/images/gamer_tree.svg'
                  aria-label='gamer_tree'
                />
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
      <Element name='RaritySc'>
        {/* <Box className='partY_ranking_main'>
          <Container maxWidth='lg'>
            <Grid container spacing={3}>
              <Grid item xs={12} md={4}>
                <Box
                  component='img'
                  src='/static/images/left_img1.jpg'
                  className='img_sdwo'
                  alt=''
                  data-aos='fade-up'
                  data-aos-duration='3000'
                />
                <Box className='contnt_cntr'>
                    <Box className='party_left_img'>
                    </Box>
                  </Box>
              </Grid>
              <Grid
                item
                xs={12}
                md={8}
                data-aos='fade-down'
                data-aos-easing='linear'
                data-aos-duration='1500'
              >
                <Typography component='h2' className='def_h'>
                  RARITY RANKING
                </Typography>
                <Typography className='def_p party_p_top'>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Consectetur sed necessitatibus cum nobis. Eum, nam. Lorem
                  ipsum, dolor sit amet consectetur adipisicing elit. Amet,
                  ratione?
                </Typography>
                <Typography className='def_p party_p_btm'>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Cumque fuga doloremque esse commodi facere perferendis eos
                  quis. Amet consectetur minima repellendus accusamus. Est,
                  nulla possimus. Lorem ipsum dolor, sit amet consectetur
                  adipisicing elit. Earum, itaque.
                </Typography>
                <Box className='party_graph_img'>
                  <Box
                    component='img'
                    src='/static/images/right_img.jpg'
                    alt=''
                  />
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box> */}
        <Box className='main_ratity'>
          <Container maxWidth='lg'>
            <Grid container spacing={3}>
              <Grid item xs={12} md={4}>
                <Typography component='h2'>
                  Rarity<span> Ranking</span>
                </Typography>
                <RarityRankingDemo />
              </Grid>
              <Grid item xs={12} md={8}>
                <Box
                  className='graph_p'
                  // data-aos='zoom-in'
                  // data-aos-duration='1500'
                >
                  <Typography>
                    All Farmers are equal, but some are more rare than others.
                    That's why we've set up a trait rarity system to tell which
                    of our Farmers are the rarest. There are a total of 57
                    traits, these have been classified in a system based on
                    levels. The traits are ranked from "Common" to "Legendary".
                    All traits and their rarity % will be announced before our
                    minting event will start. Depending on the items they have
                    in their hands, our Farmers will receive powers over time
                    that will allow them to farm in the Metaverse more or less
                    quickly.
                  </Typography>
                  <Box
                    component='img'
                    src='/static/images/rarity_ranking.svg'
                  />
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Element>
      <Element name='RoadmapSc'>
        <Box className='roadmap_man'>
          <Container maxWidth='lg'>
            <Grid container spacing={1}>
              <Grid item md={12}>
                <Box className='road_h2'>
                  <Typography component='h2' className='def_h'>
                    Roadmap
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Box className='rtdimg_prnt'>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={3} className='rdmp_md_3'>
                      <Box className='rdmp_box'>
                        <Box
                          className='rdmp_box_img'
                          // data-aos='flip-up'
                          // data-aos-duration='1500'
                        >
                          <Box
                            component='img'
                            src='/static/images/user_01.jpg'
                            alt=''
                          />
                        </Box>
                        <Box className='rdmp_dots' />
                        <Typography
                        // data-aos='zoom-in'
                        // data-aos-duration='1500'
                        >
                          Minting Event <br /> TBA December, 2021
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={3} className='rdmp_md_3'>
                      <Box className='rdmp_box'>
                        <Box
                          className='rdmp_box_img'
                          // data-aos='flip-up'
                          // data-aos-duration='1500'
                        >
                          <Box
                            component='img'
                            src='/static/images/user_02.jpg'
                            alt=''
                          />
                        </Box>
                        <Box className='rdmp_dots' />
                        <Typography
                        // data-aos='zoom-in'
                        // data-aos-duration='1500'
                        >
                          NFT Marketplace <br /> Q1 2022
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={3} className='rdmp_md_3'>
                      <Box className='rdmp_box'>
                        <Box
                          className='rdmp_box_img'
                          // data-aos='flip-up'
                          // data-aos-duration='1500'
                        >
                          <Box
                            component='img'
                            src='/static/images/user_03.jpg'
                            alt=''
                          />
                        </Box>
                        <Box className='rdmp_dots' />
                        <Typography
                        // data-aos='zoom-in'
                        // data-aos-duration='1500'
                        >
                          Treedefi on AVAX <br /> Q1 2022
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={3} className='rdmp_md_3'>
                      <Box className='rdmp_box'>
                        <Box
                          className='rdmp_box_img'
                          // data-aos='flip-up'
                          // data-aos-duration='1500'
                        >
                          <Box
                            component='img'
                            src='/static/images/user_04.jpg'
                            alt=''
                          />
                        </Box>
                        <Box className='rdmp_dots' />
                        <Typography
                        // data-aos='zoom-in'
                        // data-aos-duration='1500'
                        >
                          EcoGame <br />
                          Q1 - Q2 2022
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={3} className='rdmp_md_3'>
                      <Box className='rdmp_box'>
                        <Box
                          className='rdmp_box_img'
                          // data-aos='flip-up'
                          // data-aos-duration='1500'
                        >
                          <Box
                            component='img'
                            src='/static/images/user_05.jpg'
                            alt=''
                          />
                        </Box>
                        <Box className='rdmp_dots' />
                        <Typography
                        // data-aos='zoom-in' data-aos-duration='1500'
                        >
                          Eco DAO <br />
                          Q1 - Q2 2022
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Element>

      <Element name='ClaimSc'>
        <Box
          className='accordidn_main'
          // data-aos='fade-up'
          // data-aos-anchor-placement='center-bottom'
          // data-aos-duration='2500'
        >
          <Container maxWidth='lg'>
            <Grid container spacing={3} justifyContent={'center'}>
              <Grid item xs={12} md={8}>
                <Typography component='h2' className='def_h accordin_h2'>
                  FREQUENTLY ASKED QUESTIONS
                </Typography>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls='panel1a-content'
                    id='panel1a-header'
                  >
                    <Typography component='h2' className='accodid_hed'>
                      What will the minting price be?
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      The minting price is 1 AVAX. Early minters get a portion
                      of later purchases as a dividend, incentivizing early
                      purchases. Learn more in the tokenomics section above.
                    </Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls='panel2a-content'
                    id='panel2a-header'
                  >
                    <Typography component='h2' className='accodid_hed'>
                      When does minting start?
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      Minting event will be announcend no later than Dcecember
                      23 2021, 3PM UTC.
                    </Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls='panel3a-content'
                    id='panel3a-header'
                  >
                    <Typography component='h2' className='accodid_hed'>
                      Will there be different rarity levels for each DeFi
                      Farmer?
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      Yes, we've made 9,500 unique Farmers with various color
                      background, fur types, and accessories. The tiers are the
                      following: 1. Common (50%) 2. Rare (30%) 3. Exceptional
                      (15%) 4. Epic (4.8%) 5. Legendary (0.2%)
                    </Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls='panel3a-content'
                    id='panel3a-header'
                  >
                    <Typography component='h2' className='accodid_hed'>
                      What are the benefits for Treedefi investors?
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      Treedefi investors will benefit from our expansion on AVAX
                      trough the realese of DeFi Farmers. We are raising
                      awareness and new investors to let them know about our
                      project. This will help to improve liquidity, capitals and
                      marketing.
                    </Typography>
                  </AccordionDetails>
                </Accordion>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls='panel3a-content'
                    id='panel3a-header'
                  >
                    <Typography component='h2' className='accodid_hed'>
                      How many DeFi Farmers can I mint at a time? Is there a
                      limit per wallet?
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>
                      There is a limit of 10 Farmers per wallet, but you can
                      mint multiple farmers in the same transaction to save gas
                      fees.
                    </Typography>
                  </AccordionDetails>
                </Accordion>
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Element>
    </>
  );
}
