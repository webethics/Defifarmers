import {
  getMysteryBoxAvaxAddress,
  getTreedefiFarmersAddress,
} from './../utils/addressHelpers';
import { useEffect, useState } from 'react';
import { AbiItem } from 'web3-utils';
import { ContractOptions } from 'web3-eth-contract';
import useWeb3 from 'hooks/useWeb3';
import MysteryBox from 'abi/MysteryBox.json';
import TreedefiFarmers from 'abi/TreedefiFarmers.json';

const useContract = (
  abi: AbiItem,
  address: string,
  contractOptions?: ContractOptions
) => {
  const web3 = useWeb3();
  const [contract, setContract] = useState(
    new web3.eth.Contract(abi, address, contractOptions)
  );

  useEffect(() => {
    setContract(new web3.eth.Contract(abi, address, contractOptions));
  }, [abi, address, contractOptions, web3]);

  return contract;
};

export const useMysteryBoxAvax = () => {
  const abi = (MysteryBox.abi as unknown) as AbiItem;
  return useContract(abi, getMysteryBoxAvaxAddress());
};

export const useTreedefiFarmers = () => {
  const abi = (TreedefiFarmers.abi as unknown) as AbiItem;
  return useContract(abi, getTreedefiFarmersAddress());
};

export default useContract;
