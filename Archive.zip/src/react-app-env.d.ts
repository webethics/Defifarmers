declare module "deck.gl";
declare module "rehype-highlight";
