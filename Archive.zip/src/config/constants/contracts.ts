const addresses = {
  MysteryBoxAvax: {
    43113: '0x201Ac0A28906eD6951B18304B357Db35CCc4EcF8',
  },
  TreedefiFarmers: {
    43113: '0x2eD1b937dB0d1a43e9fe94Ef45B435E1b239179e',
  },
};

export default addresses;
