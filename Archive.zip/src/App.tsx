import { useEffect } from 'react';
// routes
import Router from './routes';
// theme
import ThemeConfig from './theme';
// components
import ScrollToTop from './components/ScrollToTop';
import NotistackProvider from './components/NotistackProvider';
import ThemePrimaryColor from './components/ThemePrimaryColor';
import Header from 'layouts/Header/header';
import { useWallet } from '@binance-chain/bsc-use-wallet';
import Footer from 'layouts/Footer/Footer';
import GoogleAnalytics from 'components/GoogleAnalytics';
import { useMoralis, useMoralisQuery } from 'react-moralis';
import ReactPixel from 'react-facebook-pixel';

// ----------------------------------------------------------------------

export default function App() {
  const { account, connect } = useWallet();
  const { Moralis, authenticate } = useMoralis();

  // ReactPixel.init('4478211285558330');

  useEffect(() => {
    const login = async () => {
      if (!account && window.localStorage.getItem('accountStatus') !== '0') {
        connect('injected');
      }

      // if (account) {
      //   const params = { accounts: account.toLowerCase() };
      //   const user = await Moralis.Cloud.run('getUsers', params);
      //   if (user && user.length == 0) {
      //     Moralis.Web3.getSigningData = () => 'Treedefi Authentication';
      //     authenticate();
      //   }
      // }
    };

    login();
  }, [account, connect]);

  return (
    <ThemeConfig>
      <ThemePrimaryColor>
        <NotistackProvider>
          {/* <Settings /> */}
          <ScrollToTop />
          {/* <GoogleAnalytics /> */}
          <Header onOpenSidebar={() => {}} />
          <div style={{ minHeight: 450 }}>
            <Router />
          </div>
          <Footer />
        </NotistackProvider>
      </ThemePrimaryColor>
    </ThemeConfig>
  );
}
