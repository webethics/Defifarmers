import { withStyles } from '@material-ui/core/styles';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
// import 'aos/dist/aos.css';
// ----------------------------------------------------------------------

const GlobalStyles = withStyles((theme) => ({
  '@global': {
    '*': {
      margin: 0,
      padding: 0,
      boxSizing: 'border-box',
    },
    html: {
      width: '100%',
      height: '100%',
      '-ms-text-size-adjust': '100%',
      '-webkit-overflow-scrolling': 'touch',
    },
    body: {
      width: '100%',
      height: '100%',
      backgroundColor: theme.palette.grey[900] + '!important',
    },
    '#root': {
      width: '100%',
      height: '100%',
    },
    input: {
      '&[type=number]': {
        MozAppearance: 'textfield',
        '&::-webkit-outer-spin-button': { margin: 0, WebkitAppearance: 'none' },
        '&::-webkit-inner-spin-button': { margin: 0, WebkitAppearance: 'none' },
      },
    },
    textarea: {
      '&::-webkit-input-placeholder': { color: theme.palette.text.disabled },
      '&::-moz-placeholder': { opacity: 1, color: theme.palette.text.disabled },
      '&:-ms-input-placeholder': { color: theme.palette.text.disabled },
      '&::placeholder': { color: theme.palette.text.disabled },
    },
    a: { color: theme.palette.primary.main },
    img: { display: 'block', maxWidth: '100%' },

    '.liveAuction': {
      zIndex: 99,
      fontFamily: 'Montserrat, sans-serif',
      position: 'absolute',
      left: 10,
      top: 10,
      fontSize: 11,
      fontWeight: 'bold',
      backgroundColor: 'rgb(16, 172, 104)',
      borderRadius: 8,
      border: '2px solid rgb(16, 172, 104)',
      color: 'rgb(255, 255, 255)',
      padding: '2px 4px',
      boxShadow: 'rgb(16 172 104 / 45%) 0px 0px 15px',
      display: 'flex',
      alignItems: 'center',
    },
    '.liveAuctionA': {
      fontFamily: 'Montserrat, sans-serif',
      float: 'right',
      display: 'flex',
      left: 10,
      top: 10,
      fontSize: 11,
      fontWeight: 'bold',
      backgroundColor: 'rgb(16, 172, 104)',
      borderRadius: 8,
      border: '2px solid rgb(16, 172, 104)',
      color: 'rgb(255, 255, 255)',
      padding: '2px 4px',
      boxShadow: 'rgb(16 172 104 / 45%) 0px 0px 15px',
      width: '30%',
      alignItems: 'center',
    },
    '.sellcard': {
      display: 'flex',
      alignItems: 'baseline',
      marginBottom: '6px',
      paddingBottom: '6px',
      borderBottom: '1px dashed',
      justifyContent: 'space-between',
    },
    '.MuiLoadingButton-loadingIndicatorEnd': {
      right: '10px',
    },
    '.blur-up': {
      WebkitFilter: 'blur(5px)',
      filter: 'blur(5px)',
      transition: 'filter 400ms, -webkit-filter 400ms',
    },
    '.blur-up.lazyloaded ': {
      WebkitFilter: 'blur(0)',
      filter: 'blur(0)',
    },
    '.cstmrd': {
      flexDirection: 'inherit',
    },
    '.cstmrd label': {
      marginLeft: 0,
      marginRight: 4,
      marginTop: 3,
    },
    '.cstmrd label .MuiIconButton-sizeMedium': {
      position: 'absolute',
      opacity: 0,
    },
    '.cstmrd label .MuiFormControlLabel-label': {
      backgroundColor: '#ececec',
      borderRadius: '35px',
      padding: '5px 15px',
      color: 'rgb(25 19 38 / 50%)',
      fontWeight: 400,
    },
    '.cstmrd label .Mui-checked + .MuiFormControlLabel-label': {
      backgroundColor: theme.palette.primary.main,
      color: theme.palette.common.white,
    },
    '.def_slct .MuiInputBase-formControl': {
      borderRadius: '35px !important',
    },
    '.def_slct .MuiSelect-select': {
      paddingTop: '5px !important',
      paddingBottom: '5px !important',
      fontSize: '14px !important',
    },
    '.csmrngsldr': {
      color: theme.palette.grey[200],
      height: '4px',
    },
    '.csmrngsldr .MuiSlider-rail': {
      height: '4px',
    },
    '.csmrngsldr .MuiSlider-track': {
      backgroundColor: theme.palette.primary.main,
      height: '4px',
    },
    '.csmrngsldr .MuiSlider-thumbColorPrimary': {
      borderColor: theme.palette.primary.main,
      border: 'solid 3px',
      width: '16px',
      height: '16px',
      marginTop: '-6px',
    },
    '.csmrngsldr .MuiSlider-markLabel': {
      color: theme.palette.grey[400],
    },
    '.csminpt .MuiInputBase-formControl': {
      borderRadius: '35px !important',
    },
    '.csminpt .MuiOutlinedInput-input': {
      paddingTop: '8px !important',
      paddingBottom: '8px !important',
      fontSize: '14px !important',
    },
    '.txtcntr .MuiOutlinedInput-input': {
      textAlign: 'center',
    },
    '.defcheckbx .MuiSvgIcon-fontSizeMedium, .def_table thead tr th .MuiSvgIcon-fontSizeMedium, .def_table tbody tr td .MuiSvgIcon-fontSizeMedium': {
      fill: theme.palette.grey[300],
    },
    '.Mui-checked .MuiSvgIcon-fontSizeMedium, .def_table thead tr th .Mui-checked .MuiSvgIcon-fontSizeMedium, .def_table tbody tr td .Mui-checked .MuiSvgIcon-fontSizeMedium': {
      fill: theme.palette.primary.main,
    },
    '.defcheckbx + .MuiFormControlLabel-label': {
      color: theme.palette.grey[500],
      fontWeight: 300,
    },
    '.Mui-checked + .MuiFormControlLabel-label': {
      color: theme.palette.primary.main,
    },
    '.defbtn': {
      borderRadius: '35px',
      fontWeight: '400',
      padding: '6px 15px',
      letterSpacing: '0.3px',
    },
    '.w-100': {
      width: '100%',
    },
    '.cstmoptn': {
      borderBottom: '1px solid',
      borderColor: '#F4F6F8 !important',
      backgroundColor: 'transparent !important',
    },
    '.cstmoptn.Mui-selected:hover, .cstmoptn.Mui-selected:hover': {
      backgroundColor: 'transparent !important',
    },
    '.cstmoptn .MuiIconButton-colorPrimary': {
      color: '#e8e8e8 !important',
    },
    '.cstmoptn .MuiListItemText-root .MuiTypography-root': {
      color: theme.palette.grey[600],
      fontWeight: 300,
    },
    '.cstmoptn.Mui-selected .MuiListItemText-root .MuiTypography-root': {
      color: theme.palette.primary.main,
    },
    '.pro_box': {
      position: 'relative',
      backgroundColor: theme.palette.common.white,
      borderRadius: '10px',
      textAlign: 'center',
      border: '2px solid transparent',
      transition: 'all 0.2s ease-out',

      // -webkit-box-shadow: "10px 10px 32px -17px rgb(0 0 0 / 25%)",
      // -moz-box-shadow: "10px 10px 32px -17px rgba(0,0,0,0.75)",
      boxShadow: '10px 10px 32px -17px rgb(0 154 80 / 24%)',
    },
    '.pro_box_v1:hover': {
      borderColor: '#D7F1E9',
    },
    '.pro_box_v2:hover': {
      borderColor: '#E3EFD9',
    },
    '.pro_box_v3:hover': {
      borderColor: '#F1DEDB',
    },
    '.pro_box_v4:hover': {
      borderColor: '#DCE7F5',
    },
    '.csmclbx': {
      padding: '30px',
      borderRadius: '10px',
      display: 'flex',
      justifyContent: 'center',
      // maxHeight: "290px",
    },
    '.csmclbx_v1': {
      backgroundColor: '#ebf8f4',
    },
    '.csmclbx_v2': {
      backgroundColor: '#f3f9ef',
    },
    '.csmclbx_v3': {
      backgroundColor: '#fef4f1',
    },
    '.csmclbx_v4': {
      backgroundColor: '#edf6ff',
    },
    '.csmclbx_v5': {
      padding: '0px',
    },
    '.LockIcon': {
      padding: '80px',
      maxwidth: '300px',
      textalign: 'center',
      margin: 'auto',
    },

    '.pro_box a': {
      textDecoration: 'none',
      // display: 'block'
    },
    '.pr_info h4': {
      fontSize: '18px',
      fontWeight: 400,
      lineHeight: '24px',
    },
    '.pr_info h4 h6': {
      fontWeight: 300,
      color: theme.palette.primary.main,
      display: 'flex',
      alignItems: 'center',
      marginTop: '5px',
    },
    '.sldr_itms': {
      padding: '10px',
    },
    '.pr_info_v2 h4': {
      color: '#212B36',
      textAlign: 'left',
    },
    '.pr_info_v2 h6': {
      textAlign: 'left',
    },
    '.pr_info h4 h6 span': {
      fontWeight: 500,
    },
    '.more_ic': {
      padding: '0 3px',
      marginLeft: 'auto',
      borderRadius: '35px',
      border: 'solid 1px',
      borderColor: theme.palette.primary.main,
    },
    '.more_ic svg': {
      height: '12px',
      fill: theme.palette.primary.main,
    },
    '.srt_btn': {
      backgroundColor: theme.palette.primary.lighter,
      color: theme.palette.primary.main,
      padding: '4px 15px',
      borderRadius: '35px',
      marginRight: '8px',
      display: 'inline-block',
      marginBottom: '5px',
    },
    '.srt_btn svg': {
      marginTop: '6px',
      marginLeft: '3px',
      display: 'inline-block',
      verticalAlign: 'top',
      cursor: 'pointer',
    },
    '.clr_btn': {
      borderRadius: '35px',
      fontWeight: 400,
      textTransform: 'uppercase',
    },
    '.dtl_tp_bx': {
      background: '#F3F9EE',
      borderRadius: '10px',
    },
    '.dtl_tp_bx_v2': {
      background: '#f3f9ef',
      borderRadius: '10px',
    },
    '.dtl_tp_bx_v3': {
      background: '#fef4f1',
      borderRadius: '10px',
    },
    '.dtl_tp_bx_v4': {
      background: '#edf6ff',
      borderRadius: '10px',
    },
    '.back_ic': {
      display: 'flex',
      alignItems: 'center',
      borderRadius: '35px',
      background: 'transparent',
      border: 'solid 1px',
      borderColor: theme.palette.grey[300],
      color: theme.palette.grey[600],
      textDecoration: 'none',
      padding: '4px 15px 4px 10px',
      textTransform: 'uppercase',
      position: 'absolute',
      left: '20px',
      top: '20px',
    },
    '.back_ic:hover': {
      background: theme.palette.grey[200],
    },
    '.back_ic_v2': {
      position: 'relative',
      left: '0px',
      top: '0px',
      marginRight: '20px',
    },
    '.ttl_btm_info p': {
      color: theme.palette.grey[500],
    },
    '.ttl_btm_info h6': {
      fontSize: '15px',
      fontWeight: 300,
      color: theme.palette.primary.main,
    },
    '.shr_icon button': {
      border: 'solid 1px',
      borderColor: theme.palette.grey[300],
      marginLeft: '8px',
    },
    '.shr_icon button svg': {
      color: theme.palette.grey[500],
    },
    '@media screen and (max-width: 636px)': {
      '.td_d_rsp': {
        display: 'block !important',
      },
      '.shr_icon': {
        marginTop: '20px',
      },
      '.shr_icon button': {
        marginLeft: '0px',
        marginRight: '8px',
      },
    },
    '.plcb_bx': {
      display: 'flex',
      alignItems: 'center',
    },
    '.csm_src': {
      width: '100%',
      maxWidth: '430px',
    },
    '.csm_src .MuiFormControl-marginNormal': {
      width: '100%',
    },
    '.csm_src fieldset': {
      border: 'none !important',
      backgroundColor: theme.palette.common.white,
      borderRadius: '35px',
      zIndex: '-1',
    },
    '.csm_src label': {
      color: theme.palette.grey[400],
      fontWeight: 300,
    },
    '.csm_src button': {
      borderRadius: '35px',
      height: '42px',
      fontSize: '16px',
      fontWeight: 500,
      textTransform: 'uppercase',
      position: 'absolute',
      right: '8px',
      top: '8px',
      boxShadow: 'none',
    },
    '.csm_src_v2 button': {
      position: 'relative',
      right: '0px',
      top: '0px',
      padding: '6px 32px',
      marginLeft: 'auto',
    },
    '.wtmrpddng': {
      padding: '6px 30px',
      paddingRight: '36px',
    },
    '.def_tabs': {
      backgroundColor: theme.palette.common.white,
      boxShadow: 'none',
    },
    '.def_tabs .css-1tzeyse-MuiTabs-indicator': {
      display: 'none',
    },
    '.def_tabs .MuiTabs-fixed': {
      textAlign: 'center',
    },
    '.def_tabs .MuiTabs-flexContainer': {
      display: 'inline-block',
      justifyContent: 'center',
      backgroundColor: theme.palette.primary.lighter,
      borderRadius: '10px',
      padding: '2px',
    },
    '.def_tabs .MuiTabs-flexContainer button': {
      backgroundColor: theme.palette.primary.lighter,
      color: theme.palette.primary.main,
      margin: '0',
      minHeight: 'inherit',
      fontWeight: 300,
      fontSize: '16px',
      borderRadius: '10px',
      padding: '3px 30px',
      minWidth: '140px',
    },
    '.def_tabs .MuiTabs-flexContainer button.Mui-selected, .def_tabs .MuiTabs-flexContainer button:hover': {
      backgroundColor: theme.palette.common.white,
    },
    '.def_table thead tr th': {
      backgroundColor: theme.palette.grey[200],
      fontWeight: '400',
      color: theme.palette.grey[500],
      paddingTop: '5px !important',
      paddingBottom: '5px !important',
    },
    '.def_table tbody tr td, .def_table tbody tr th': {
      fontWeight: '400',
      color: theme.palette.common.black,
      paddingTop: '12px !important',
      paddingBottom: '12px !important',
    },
    '.def_table tbody tr th': {
      paddingLeft: '16px !important',
    },
    '.def_table thead tr th .MuiCheckbox-colorPrimary': {
      paddingTop: '0px !important',
      paddingBottom: '0px !important',
      background: 'transparent !important',
    },
    '.def_table tbody tr td span': {
      fontWeight: '400',
    },
    '.deffrmcntrl': {
      display: 'block',
    },
    '.deffrmcntrl .MuiFormControl-root': {
      width: '100%',
    },
    '.deffrmcntrl label': {
      fontSize: '15px',
      fontWeight: '400',
      color: theme.palette.grey[600],
      marginBottom: '3px',
      display: 'block',
    },
    '.deffrmcntrl .MuiInputBase-input': {
      padding: '12.5px 14px',
      fontWeight: 300,
    },
    '.deffrmcntrl fieldset': {
      borderRadius: '10px',
      borderColor: theme.palette.grey[300] + '!important',
    },
    '.def_slct_prmr fieldset': {
      border: 'none !important',
    },
    '.def_slct_cprmr fieldset': {
      border: 'none !important',
    },
    '.def_slct.def_slct_prmr .MuiSelect-select, .def_slct.def_slct_prmr svg': {
      color: theme.palette.primary.main,
    },
    '.def_slct.def_slct_cprmr .MuiSelect-select, .def_slct.def_slct_prmr svg': {
      color: theme.palette.primary.main,
    },
    '.def_slct.def_slct_prmr .MuiSelect-select': {
      backgroundColor: theme.palette.primary.lighter,
      paddingTop: '8px !important',
      paddingBottom: '8px !important',
    },
    '.def_slct.def_slct_cprmr .MuiSelect-select': {
      backgroundColor: theme.palette.primary.lighter,
      paddingTop: '5px !important',
      paddingBottom: '5px !important',
    },
    '.MuiModal-root .MuiDialog-container .MuiPaper-rounded': {
      borderRadius: '32px !important',
    },
    '.MuiModal-root .MuiDialog-container .MuiPaper-rounded h5': {
      fontWeight: 600,
    },
    '.mdl_c_btn': {
      backgroundColor: theme.palette.grey[200] + '!important',
      color: theme.palette.primary.main + '!important',
      marginBottom: '10px !important',
      padding: '7px 20px !important',
      fontWeight: '600 !important',
      borderRadius: '10px !important',
      textTransform: 'inherit !important',
    },
    '.mdl_c_btn:hover': {
      backgroundColor: theme.palette.grey[300] + '!important',
    },
    '.def_slct_abslt': {
      position: 'absolute',
      right: '4px',
      top: '4px',
      maxWidth: '115px',
    },
    '.lrn_btn': {
      display: 'flex',
      alignItems: 'center',
      textDecoration: 'none',
      fontWeight: 500,
      fontSize: '18px',
    },
    '.full_header header.MuiAppBar-positionFixed': {
      width: '100% !important',
    },
    '.m_logo': {
      display: 'none',
    },
    '.min_100vh': {
      height: '100vh',
    },
    '.MuiDrawer-modal>.MuiBackdrop-root': {
      display: 'none !important',
    },
    '.MuiDrawer-paperAnchorLeft': {
      transition: 'all 0.2s ease-out',
    },
    '.p_l_290': {
      transition: 'all 0.2s ease-out',
    },

    '.sidebar-open': {
      overflowY: 'auto !important',
    },
    '.sidebar-open .MuiDrawer-paperAnchorLeft': {
      left: '-280px',
    },
    '.pro_box_min_height': {
      minHeight: '500px',
    },
    '.popover_p>div': {
      display: 'inline-block',
      verticalAlign: 'middle',
    },
    '.tltp_bx': {
      background: theme.palette.common.white,
      color: '#3BB78F',
      boxShadow: '0 0 5px 0 rgb(0,0 ,0,10%)',
      padding: '10px',
      borderRadius: '5px',
      fontSize: '15px',
      fontWeight: 400,
      maxWidth: '260px',
    },
    '.defmdl .MuiBackdrop-root': {
      background: 'rgba(0, 0, 0, 0.5)',
      borderRadius: 0,
    },
    '.defmdl .MuiDialogTitle-root h2': {
      fontWeight: 600,
      fontSize: '1.5rem',
    },
    '.defmdl .MuiDialogTitle-root h2 .MuiIconButton-root': {
      top: '15px',
      right: '8px',
      position: 'absolute !important',
    },
    '.defmdl .MuiDialogActions-root .MuiButton-root': {
      fontSize: '16px',
      fontWeight: 400,
    },
    iframe: {
      border: 'none',
      pointerEvents: 'none !important',
    },
    '.blob': {
      background: 'black',
      borderRadius: '50%',
      boxShadow: '0 0 0 0 rgba(0, 0, 0, 1)',
      margin: '6px',
      height: '8px',
      width: ' 8px',
      transform: 'scale(1)',
      animation: 'pulse-black 2s infinite',
    },
    '.blob.green_b': {
      background: 'rgb(102 241 208)',
      boxShadow: '0 0 0 0 rgba(102, 241, 208, 1)',
      animation: 'pulse-green 2s infinite',
    },
    '.csmclbx.csmclbx_v1': { display: 'block !important' },
    '.d_flex': {
      display: 'flex',
    },
    '@keyframes pulse-green': {
      '0%': {
        transform: 'scale(0.95)',
        boxShadow: '0 0 0 0 rgba(102, 241, 208, 0.7)',
      },

      '70%': {
        transform: 'scale(1)',
        boxShadow: '0 0 0 10px rgba(102, 241, 208, 0)',
      },

      '100%': {
        transform: 'scale(0.95)',
        boxShadow: '0 0 0 0 rgba(102, 241, 208, 0)',
      },
    },
    '.sbttl': {
      display: 'block',
      color: theme.palette.primary.main,
      fontSize: '15px',
      fontWeight: 400,
      marginTop: '-5px',
    },
    '.defwt_bx': {
      background: theme.palette.common.white,
      boxShadow: '0px 16px 32px #919EAB1A',
      borderRadius: '16px',
      padding: '30px 30px',
      minHeight: '270px',
    },
    '.defwt_bx_1': {
      background: theme.palette.common.white,
      boxShadow: '0px 16px 32px #919EAB1A',
      borderRadius: '16px',
      padding: '30px 30px',
      minHeight: '270px',
      display: 'flex',
      flexDirection: 'column',
      flexWrap: 'wrap',
      alignContent: 'center',
      justifyContent: 'center',
    },
    '.whtbx1_cntnt h4': {
      fontSize: '28px',
      fontWeight: 600,
      color: '#191326',
      marginBottom: '10px',
    },
    '.whtbx1_cntnt h6': {
      color: '#0BAB64',
      fontSize: '16px',
      fontWeight: 400,
      marginBottom: '10px',
    },
    '.whtbx1_cntnt h6 span': {
      display: 'block',
      fontSize: '20px',
      fontWeight: '600 !important',
      color: '#191326',
    },
    '.whtbx1_cntnt_flx h6': {
      display: 'flex',
      alignItems: 'center',
    },
    '.whtbx1_cntnt_flx h6 span': {
      marginLeft: 'auto',
    },
    '.whtbx1_cntnt_v2': {
      textAlign: 'center',
    },
    '.blnc_ic_bx': {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '80px',
      width: '80px',
      borderRadius: '50%',
      background: '#0BAB64',
      margin: '0 auto 18px auto',
    },
    '.amb-0': { marginBottom: '0 !important' },
    '.whtbx1_cntnt_v3 h6': { marginBottom: '5px' },
    '.whtbx1_cntnt_v2 h6': { marginBottom: '0' },
    '.whtbx1_cntnt_v2 h6 span': {
      fontSize: '24px',
    },
    '.whtbx1_cntnt_v4 h6': {
      marginBottom: '0',
    },
    '.whtbx1_cntnt_v4 h6 span': {
      fontSize: '24px',
      display: 'flex',
      alignItems: 'center',
    },
    '.tab_ttl': {
      fontSize: '24px',
      fontWeight: 600,
      color: '#191326',
      marginBottom: '-35px',
    },
    '.def_table_v2 tbody td .MuiIconButton-root': {
      borderRadius: '10px',
      background: 'rgba(11,171,100,0.1)',
      color: '#0BAB64',
      padding: '5px 2px 5px 8px',
      transform: 'rotate(0deg) !important',
    },
    '.def_table_v2 tbody td .MuiIconButton-root[aria-expanded="true"]': {
      background: '#0BAB64',
      color: theme.palette.common.white,
    },
    '.def_table_v2 tbody td .MuiIconButton-root label': {
      fontSize: '14px',
      cursor: 'pointer',
    },
    '.def_table_v2 tbody td .MuiIconButton-root svg': {
      transform: 'rotate(-90deg) !important',
      fill: '#0BAB64',
    },
    '.def_table_v2 tbody td .MuiIconButton-root[aria-expanded="true"] svg': {
      transform: 'rotate(0deg) !important',
      fill: theme.palette.common.white,
    },
    '.def_table_v2 tbody td .PrivateSwitchBase-root': {
      borderRadius: '10px',
      background: 'transparent',
      color: 'transparent',
      padding: '5px 2px 5px 8px',
      transform: 'rotate(0deg) !important',
    },
    '.def_table_v2 tbody td .PrivateSwitchBase-root[aria-expanded="true"]': {
      background: '#0BAB64',
      color: theme.palette.common.white,
    },
    '.def_table_v2 tbody td .PrivateSwitchBase-root label': {
      fontSize: '14px',
      cursor: 'pointer',
    },
    '.def_table_v2 tbody td .PrivateSwitchBase-root svg': {
      transform: 'rotate(0deg) !important',
      fill: '#0BAB64',
    },
    '.def_table_v2 tbody td .PrivateSwitchBase-root[aria-expanded="true"] svg': {
      transform: 'rotate(0deg) !important',
      fill: theme.palette.common.white,
    },
    '.tbl_cllps': { padding: '0 15px' },
    '.def_table_v2 tbody tr:nth-child(even) td': {
      padding: '0 !important',
    },
    '.tblinn_bx': {
      background: '#FAF9FA',
      border: '1px solid #FAF9FA',
      borderRadius: '16px',
      padding: '15px 20px',
    },
    '.tblinn_bx h3': {
      fontSize: '18px',
      fontWeight: 600,
      color: '#191326',
      marginBottom: '10px',
    },
    '.tbl_inptbx': {
      position: 'relative',
      marginBottom: '10px',
    },
    '.tbl_inptbx input': {
      width: '100%',
      outline: 'none',
      padding: '12px',
      background: theme.palette.common.white,
      border: '1px solid #0000001A',
      borderRadius: '10px',
    },
    '.tbl_inptbx label': {
      position: 'absolute',
      right: '10px',
      top: '10px',
      color: '#0BAB64',
      opacity: 0.5,
      fontSize: '15px',
    },
    '.tblactnbx': {
      display: 'flex',
      alignItems: 'center',
    },
    '.tblactnbx button': {
      borderRadius: '29px',
      width: '100%',
      marginBottom: '8px',
      padding: '8px',
      boxShadow: 'none !important',
    },
    '.asmr-2': { marginRight: '10px' },
    '.tbl_btn_01': {
      background: '#E99400',
    },
    '.tbl_btn_01:hover': {
      background: '#cd8302',
    },
    '.tbl_btn_02': {
      background: '#0BAB64',
    },
    '.tbl_btn_02:hover': {
      background: '#049152',
    },
    '.tbl_btn_03': {
      background: 'rgba(171,11,11,0.1) ',
      color: '#AB0B0B',
    },
    '.tbl_btn_03:hover': {
      background: 'rgba(171,11,11,0.2) ',
    },
    '.tbbn_inn_ttllbl': {
      color: '#0BAB64',
      fontSize: '24px',
      lineHeight: '26px',
      display: 'block',
    },
    '.tbbn_inn_fees': {
      color: '#FFCC00',
      fontSize: '14px',
      marginTop: '-10px',
      display: 'block',
      marginBottom: '10px',
    },
    '.asmd_5': {
      flexBasis: '38.666667% !important',
    },
    '.asmd_2': {
      flexBasis: '22.666667% !important',
      maxWidth: '22.666667% !important',
    },
    '.ltrttlbk': {
      display: 'flex',
      alignItems: 'center',
    },
    '.ltrttlbk h2': {
      marginRight: '130px',
    },
    '.ltrttlbk p': {
      color: theme.palette.primary.main,
      fontSize: '15px',
      fontWeight: 400,
    },
    '.lrt_wt_bx': {
      background: theme.palette.common.white,
      boxShadow: '0px 16px 32px #919EAB1A',
      borderRadius: '16px',
      padding: '30px 30px',
    },
    '.ttlflx': {
      display: 'flex',
      alignItems: 'center',
    },
    '.lrt_wt_bx.debug': {
      border: '1px solid red',
    },
    '.lrt_wt_ttl h4': {
      fontWeight: 600,
    },
    '.lrt_wt_ttl h5': {
      fontWeight: 500,
      marginLeft: 'auto',
      fontSize: '22px',
      color: '#ABABAB',
    },
    '.lrt_wt_ttl h5 span': {
      color: theme.palette.primary.main,
    },
    '.lrt_wt_ttl h5 small': {
      fontSize: '20px',
      fontWeight: 300,
      margin: '0 3px',
    },
    '.sm_ltr_bx': {
      background: theme.palette.common.white,
      border: '1px solid #0BAB6433',
      borderRadius: '16px',
      padding: '8px 15px',
    },
    '.sm_ltr_bx label': {
      fontSize: '14px',
      fontWeight: 400,
      color: theme.palette.primary.main,
    },
    '.sm_ltr_bx h5': {
      fontWeight: 600,
    },
    '.eco_mn': {
      paddingTop: '80px',
    },
    '.eco_mn h2': {
      fontSize: '42px',
      fontWeight: 600,
      color: '#191326',
    },
    '.eco_wt_bx': {
      position: 'relative',
      background: '#FFFFFF',
      boxShadow: '0px 8px 16px #0000000D',
      borderRadius: '10px',
      overflow: 'hidden',
      marginBottom: '20px',
    },
    '.sco_info': {
      padding: '35px',
    },
    '.sco_info h3': {
      fontSize: '42px',
      fontWeight: 600,
      color: '#191326',
    },
    '.sco_info p': {
      fontSize: '18px',
      fontWeight: 300,
      color: '#000',
      opacity: 0.5,
      marginBottom: '35px',
    },
    '.ecctble table thead th': {
      background: '#FAF9FA',
      letterSpacing: '0.32px',
      color: 'rgba(25,19,38,0.3)',
      textTransform: 'uppercase',
      borderRadius: '4px !important',
      padding: '5px 15px !important',
      boxShadow: 'none !important',
    },
    '.ecctble table tbody td': {
      padding: '7px 15px !important',
      borderBottom: '1px solid rgba(0,0,0,0.02)',
      fontSize: '18px',
      fontWeight: 400,
    },
    '.assktln': {
      width: '100%',
      backgroundColor: '#e9e9e9',
    },
    '.lstng_itmsldr': {
      marginBottom: '30px',
    },
    '.lstng_itmsldr .slick-arrow::before': {
      color: '#3bb78f',
    },
    '.lstng_itmsldr .pro_box': {
      boxShadow: '10px 10px 22px -17px rgba(0,154,80,0.24)',
    },
    '.liveAuctionOrang': {
      border: '2px solid rgb(235 186 26) !important',
      boxShadow: 'rgba(235,186,26,0.65) 0px 0px 15px !important',
      backgroundColor: 'rgb(235 186 26) !important',
    },
    '.liveAuctionRed': {
      border: '2px rgb(227 129 95) !important',
      boxShadow: 'rgba(241,62,0,0.55) 0px 0px 15px !important',
      backgroundColor: 'rgb(227 129 95) !important',
    },
    '.sale_stckr': {
      position: 'absolute',
      right: 0,
      top: 0,
    },
    '.sale_modal .MuiPaper-elevation': {
      minWidth: '800px',
    },
    '.sale_modal': {
      zIndex: '99999 !important',
    },
    '.sale_modal .mdl_bd': {
      background: '#101010',
    },
    '.sale_modal .MuiBackdrop-root': {
      background: 'rgba(0,0,0,0.50) !important',
    },
    '.mdl_bd': {
      display: 'flex',
      alignItems: 'flex-start',
      color: '#fff',
    },
    '.inn_mdl_bd': {
      position: 'absolute',
      right: 0,
      top: 0,
      padding: '50px 40px 30px 40px',
      maxWidth: '395px',
      display: 'flex',
      flexDirection: 'column',
    },
    '.inn_mdl_bd h1': {
      fontSize: '36px',
      fontWeight: 600,
      color: '#FFFFFF',
      marginBottom: '12px',
    },
    '.inn_mdl_bd p, .inn_mdl_bd h6': {
      fontSize: '17px',
      lineHeight: '24px',
      marginBottom: '35px',
      color: '#fff',
      fontWeight: 300,
    },
    '.inn_mdl_bd h6': {
      textAlign: 'right',
      marginBottom: '15px',
    },
    '.inn_mdl_bd h6 a': {
      color: '#6F9B37',
      marginBottom: '15px',
    },
    '.tkyrrs_btn': {
      backgroundColor: '#6F9B37 !important',
      borderRadius: '27px',
      border: 'none !important',
      boxShadow: 'none !important',
      color: '#FFFFFF',
      padding: '8px 26px',
      display: 'flex',
      marginLeft: 'auto',
      marginBottom: '40px',
      fontStyle: 'italic',
    },
    '.tkyrrs_btn:hover': {
      backgroundColor: '#94c351 !important',
    },
    '.inn_mdl_bd h5': {
      color: '#FFFFFF',
      opacity: '0.2',
      textAlign: 'right',
    },
    '.brngng_bnr_prnt': {
      marginTop: '64px',
      position: 'relative',
    },
    '.bnr_cntnt': {
      position: 'absolute',
      zIndex: '1',
      top: '110px',
      width: '100%',
    },
    '.def_h': {
      textAlign: 'left !important',
      font: 'normal normal 600 62px/66px Kanit !important',
      letterSpacing: '0px !important',
      color: '#000000 !important',
      opacity: '1',
    },
    '.avx_bxc': {
      marginTop: '24px',
    },
    '.avx_bxc button': {
      background: '#3AB78F 0% 0% no-repeat padding-box',
      borderRadius: '25px',
      opacity: '1',
      marginRight: '20px',
      fontSize: '18px',
      fontWeight: '300',
    },
    '.abt_farmer': {
      minHeight: '496px',
      display: 'flex',
      alignItems: 'center',
      padding: '40px 0',
    },
    '.tdimg_prnt': {
      paddingRight: '86px !important',
    },
    '.img_canter': {
      display: 'flex',
      justifyContent: 'center',
      padding :'0 !important',
    },
    '.td_contant .def_p': {
      marginTop: '10px !important',
    },
    '.def_p': {
      font: 'normal normal 300 20px/30px Kanit !important',
      color: '#000000',
      opacity: '0.7',
      letterSpacing: '0px',
    },
    '.td_contant': {
      paddingTop: '30px',
    },
    '.becom_far': {
      background: '#3AB78F 0% 0% no-repeat padding-box',
      opacity: '1',
      position: 'relative',
      padding: '49px 0',
    },
    '.top_img': {
      position: 'absolute',
      top: '0',
      left: '0',
      background: ' transparent',
      mixBlendMode: 'color-dodge',
      pointerEvents: 'none',
    },
    '.bottom_img': {
      position: 'absolute',
      mixBlendMode: 'color-dodge',
      bottom: '0',
      right: '0',
    },
    '.farmer_man_img': {
      position: 'relative',
      display: 'inline-block',
    },
    '.dot_img_01': {
      position: 'absolute',
      bottom: '0',
      right: '26px',
    },
    '.farmer_img_01': {
      position: 'relative',
      zIndex: '1',
    },
    '.dot_img_02': {
      position: 'absolute',
      bottom: '0',
      left: '26px',
    },
    '.farmer_img_02': {
      position: 'relative',
      zIndex: '1',
    },
    '.becm_fr .def_h': {
      color: '#FFFFFF !important',
      letterSpacing: '0 !important',
      textAlign: 'center !important',
      marginTop: '44px',
    },
    '.becm_fr p': {
      color: '#FFFFFF',
      textAlign: 'center',
      font: 'normal normal 300 22px/33px Kanit',
      letterSpacing: '0.88px',
      opacity: '1',
    },
    '.abt_td_pddngh': {
      paddingLeft: '110px',
    },
    '.tockenomics_bg_main': {
      background:
        'url(/static/images/sc_background.jpg) no-repeat padding-box 0 0',
      minHeight: '740px',
      backgroundSize: 'cover',
      padding: '70px 15px 50px 15px',
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justfyContant: 'center',
    },
    '.three_p': {
      maxWidth: '707px',
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      marginTop: '21px',
    },
    '.three_p p': {
      textAlign: 'center',
      color: '#FFFFFF',
      marginBottom: '22px',
    },
    '.three_p .def_h': {
      textAlign: 'center !important',
      color: '#FFFFFF !important',
      marginBottom: '20px',
    },
    '.about_bg_01': {
      background: 'url(/static/images/about_bg.jpg) no-repeat padding-box 0 0',
      minHeight: '480px',
      backgroundSize: 'cover',
    },
    '.abt_h2_1 h2': {
      color: '#fff !important',
    },
    '.abt_h2_1 p': {
      color: '#fff !important',
    },
    '.road_h2 h2': {
      textAlign: 'center !important',
      marginBottom: '30px',
    },
    becm_fr: {
      display: 'flex',
      flexDirection: 'column',
    },
    '.counterDisplay': {
      margin: '20px auto 0 auto',
      display: 'flex',
    },
    '.qntt_box': {
      position: 'relative',
      width: '210px',
      marginRight: '8px',
    },
    '.qntt_box input': {
      background: '#fff',
      borderRadius: '25px',
      border: 'none !important',
      outline: 'none !important',
      height: '42px',
      color: '#000',
      padding: '0 15px',
      width: '100%',
      textAlign: 'center',
      fontSize: '22px',
    },
    '.qntt_box button': {
      background: '#000 !important',
      position: 'absolute',
      left: '3px',
      top: '3px',
      borderRadius: '25px',
      padding: 0,
      height: '36px',
      width: '36px',
      minWidth: 'inherit',
      color: '#fff',
      fontWeight: 300,
      fontSize: '24px',
      lineHeight: '18px',
    },
    '.qntt_box button.qnttbtnrgt': {
      left: 'auto',
      right: '3px',
    },
    '.counterDisplay .AddBtn': {
      background: '#fff',
      borderRadius: '25px',
      border: 'none !important',
      outline: 'none !important',
      height: '42px',
      color: '#3AB78F',
      padding: '0 20px',
      textAlign: 'center',
      fontSize: '18px',
      fontWeight: 500,
    },
    '.becm_fr': {
      display: 'flex',
      flexDirection: 'column',
    },
    '.qntt_btntxt': {
      fontSize: '16px !important',
      marginTop: '12px',
    },
    '.qntt_btntxt span': {
      display: 'inline-block',
      margin: '0 15px',
    },
    '.roadmap_man': {
      padding: '60px 0',
      background: '#fff',
    },
    '.rtdimg_prnt': {
      position: 'relative',
    },
    '.rdmp_md_3': {
      textAlign: 'center',
      display: 'flex',
      maxWidth: '20%',
      flexBasis: '20%',
    },
    '.rdmp_box': {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-start',
      alignItems: 'center',
      margin: '0 auto',
    },
    '.rdmp_box_img': {
      boxShadow: '0px 16px 32px #0000001a',
      padding: '8px',
      marginBottom: '25px',
    },
    '.rdmp_box_img img': {
      width: '100%',
    },
    '.rdmp_box p': {
      letterSpacing: '0px',
      color: '#000000',
      fontSize: '18px',
      fontWeight: '300',
      textAlign: 'center',
      maxWidth: '160px',
      margin: '0 auto',
    },
    '.rdmp_dots': {
      border: '5px solid #3AB78F',
      borderRadius: '50%',
      height: '17px',
      width: '17px',
      margin: '0 auto 10px auto',
      background: '#fff',
      position: 'relative',
    },
    '.rtdimg_prnt:before': {
      content: '""',
      borderBottom: '2px dashed #3AB78F',
      position: 'absolute',
      left: '10%',
      top: '198px',
      right: '10%',
    },
    // '@media screen and (min-width: 320px)': {
    //   '.about_bg_01':{
    //     minHeight: '450px !important',
    //   },
    // },
    '.clm_box': {
      display: 'flex',
      border: '1px solid #3BB78F',
      borderRadius: '25px',
      alignItems: 'center',
      marginRight: '12px',
      textTransform: 'uppercase',
    },
    '.clm_box h4': {
      color: '#000000',
      padding: '0 12px',
      fontSize: '0.875rem',
    },
    '.clm_box button': {
      textTransform: 'uppercase',
    },
    '.partY_ranking_main': {
      padding: '50px 0',
    },
    '.partY_ranking_main .part_h': {
      textAlign: 'left !important',
      font: 'normal normal 600 35px/44px Kanit !important',
      letterSpacing: '0px !important',
      color: '#000000 !important',
      opacity: '1',
    },
    '.partY_ranking_main .party_p_top': {
      marginTop: '25px',
    },
    '.partY_ranking_main .party_p_btm': {
      margin: '20px 0',
    },
    '.party_left_img': {
      padding: '50px 30px 0 30px',
    },
    '.partY_ranking_main .img_sdwo': {
      borderRadius: '30px',
      boxShadow: '0px 10px 10px 0 rgba(0, 0, 0, 0.1)',
    },
    '.accordidn_main': {
      padding: '50px 0',
    },
    '.accordin_h2': {
      font: 'normal normal 600 40px/54px Kanit !important',
      textAlign: 'center !important',
      marginBottom: '20px',
    },
    '.MuiAccordionSummary-expandIconWrapper': {
      position: 'relative',
      top: '2px',
    },
    '.MuiAccordionSummary-content': {
      order: '2',
    },
    '.css-1l9qnyh-MuiPaper-root-MuiAccordion-root.Mui-expanded ': {
      backgroundColor: 'transparent',
      boxShadow: 'none',
    },
    '.accordidn_main p': {
      marginBottom: '5px',
      font: 'normal normal 400 16px/22px Kanit !important',
    },
    '.accordidn_main .accodid_hed': {
      font: 'normal normal 600 20px/22px Kanit !important',
    },
    ' .accordidn_main .css-o4b71y-MuiAccordionSummary-content.Mui-expanded': {
      margin: '0 !important',
    },
    '.accordidn_main .css-90h10p-MuiButtonBase-root-MuiAccordionSummary-root.Mui-expanded': {
      minHeight: '48px !important',
    },
    '.accordidn_main .css-1l9qnyh-MuiPaper-root-MuiAccordion-root.Mui-expanded': {
      margin: '12px 0 !important',
    },
    '.animtin_imgs': {
      width: '100%',
    },
    ' .accordidn_main .MuiPaper-rounded ': {
      background: 'transparent',
    },
    '.mnicon_btn': {
      display: 'none',
    },
    '.sc_header': {
      display: 'flex',
      alignItems: 'center',
      width: '100%',
    },
    '.mdlmenu': {
      margin: '0 auto',
    },

    '.mdlmenu a': {
      fontSize: '16px',
      textDecoration: 'none',
      color: '#000',
      margin: '0 20px',
      cursor: 'pointer',
      transition: 'all 0.2s ease-out',
    },
    '.mdlmenu a:hover, .mdlmenu a.active': {
      color: '#3BB78F',
    },
    '.main_ratity': {
      background: 'url(/static/images/rarity_bg_img.png) no-repeat 0 0',
      minHeight: '480px',
      backgroundSize: 'cover',
      padding: '90px 40px',
    },
    '.main_ratity h2': {
      fontSize: '50px',
      color: 'red',
      fontWeight: '600',
      textAlign: 'center',
      marginBottom: '15px',
    },
    '.main_ratity span': {
      color: '#000',
      fontWeight: '400',
    },
    '.main_ratity .farmer_box': {
      backgroundColor: '#fff',
      borderRadius: '30px',
      overflow: 'hidden',
      paddingBottom: '35px',
    },
    '.farmer_666': {
      display: 'flex',
      padding: '20px',
      alignItems: 'center',
    },
    '.farmer_666 h5': {
      fontSize: '20px',
      fontWeight: '700',
    },
    '.farmer_666 .img_apply': {
      marginLeft: 'auto !important',
    },
    '.main_ratity .graph_p ': {
      padding: '50px',
      backgroundColor: 'rgba(255, 255, 255, 0.25)',
      borderRadius: '20px',
    },
    '.main_ratity .graph_p p': {
      fontSize: '20px',
      fontWeight: '500',
      marginBottom: '40px',
    },
    '.prgrss_main_box': {
      padding: '0 20px 20px 20px',
    },
    '.prgrss_main_box .head_pgrss': {
      display: 'flex',
      alignItems: 'center',
      width: '100%',
    },
    '.prgrss_main_box .head_pgrss p': {
      minWidth: '100px',
      fontSize: '16px',
      fontWeight: '600',
    },
    '.prgrss_main_box .head_pgrss .def_prgrss': {
      display: 'flex',
      alignItems: 'center',
      width: '100%',
      justifyContent: 'space-between',
    },
    '.prgrss_main_box .head_pgrss .def_prgrss .MuiLinearProgress-root': {
      width: '100%',
      marginLeft: '5px',
      height: '10px',
      backgroundColor: '#e4e4e4',
    },
    '.prgrss_main_box .head_pgrss .def_prgrss .MuiLinearProgress-root .MuiLinearProgress-bar': {
      backgroundColor: '#ff0000',
    },
    '.farmer_box': {
      boxShadow: '4px 0px 10px 0 rgba(0,0,0,0.28)',
      borderRadius: '18px',
    },
    '.skltnpddng': {
      padding: '0 15px',
    },
    '@media screen and (max-width: 1366px)': {
      '.becm_fr p': {
        font: 'normal normal 300 21px/31px Kanit',
      },
      '.def_h': {
        fontSize: '50px !important',
        lineHeight: '56px !important',
      },
      '.def_p': {
        font: 'normal normal 300 19px/28px Kanit !important',
      },
    },

    '@media screen and (min-width: 1280px)': {
      '.p_l_290': { paddingLeft: '290px' },
      '.sidebar-open .p_l_290': {
        paddingLeft: '16px',
      },
    },
    '@media screen and (min-width: 992px)': {
      '.filterButton': { position: 'absolute', right: '40px', top: '5px' },
    },

    '@media screen and (max-width: 1279px)': {
      '.def_table_v2': {
        width: '1190px !important',
      },
      '.sidebar-open header': {
        zIndex: '99999',
      },
      // ".MuiDrawer-root.MuiDrawer-modal": {
      //   pointerEvents: "none",
      // },
      '.sidebar-open .MuiModal-root.MuiDrawer-root.MuiDrawer-modal': {
        left: '-280px',
        right: 'auto',
        pointerEvents: 'visible',
      },
      body: {
        overflow: 'inherit !important',
      },
    },
    '@media screen and (max-width: 1199px)': {
      '.main_ratity h2': {
          fontSize: '39px',
        },
        '.main_ratity .graph_p p': {
          fontSize: '18px',
        },
        '.partY_ranking_main .part_h': {
          font: 'normal normal 600 28px/38px Kanit !important',
        },
        '.becm_fr p': {
          font: 'normal normal 300 19px/30px Kanit',
        },
        '.bnr_cntnt': {
          top: '50px',
        },
        '.def_h': {
          fontSize: '43px !important',
          lineHeight: '48px !important',
        },
        '.def_p': {
          font: 'normal normal 300 18px/27px Kanit !important',
        },
        '.mdlmenu a': {
          margin: '0 5px',
          fontSize: '12px',
      },
    },
    '@media screen and (max-width: 959px)': {
      '.main_ratity .farmer_box img': {
        margin: '0 auto !important',
      },
      '.main_ratity .farmer_box .img_apply': {
        marginLeft: 'auto !important',
        marginRight: '0 !important',
      },
      '.contnt_cntr': {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        width: '100%',
      },
      '.fr_ordr': {
        order: '2',
      },
      '.tx_alin': {
        textAlign: 'center',
      },
    },
    '@media screen and (max-width: 991px)': {
      '.becm_fr p': {
        font: 'normal normal 300 17px/28px Kanit',
      },
      '.td_contant': {
        paddingLeft: '0px',
      },
      '.bnr_cntnt': {
        top: '100px',
      },
      '.brngng_bnr_prnt': {
        background: '#deffff',
        paddingTop: '150px',
        marginTop: '20px',
      },
      '.def_h': {
        fontSize: '35px !important',
        lineHeight: '40px !important',
      },
      '.def_p': {
        font: 'normal normal 300 17px/25px Kanit !important',
      },
      '.mdl_bd': { flexDirection: 'column' },
      '.inn_mdl_bd': {
        position: 'relative',
        padding: '20px 10px 20px 10px',
        maxWidth: '100%',
      },
      '.sale_modal .MuiPaper-elevation': {
        minWidth: 'inherit',
      },
      '.d_logo': {
        display: 'none',
      },
      '.m_logo': {
        display: 'block',
      },
      '.MuiDrawer-paperAnchorLeft': {
        left: '-280px',
      },
      '.sidebar-open .MuiDrawer-paperAnchorLeft': {
        left: '0',
      },
      ".MuiModal-root.MuiDrawer-root.MuiDrawer-modal[role='presentation']": {
        pointerEvents: 'none',
      },
      '.sidebar-open .MuiModal-root.MuiDrawer-root.MuiDrawer-modal': {
        pointerEvents: 'visible',
      },
      '.rtdimg_prnt:before': {
        display: 'none !important',
      },
      '.rdmp_md_3': {
        maxWidth: '33.33%',
        flexBasis: '33.33%',
      },
      '.mnicon_btn': {
        display: 'block',
      },
      '.sc_header': {
        position: 'absolute',
        right: 0,
        top: '55px',
        background: '#fff',
        padding: '30px',
        boxShadow: '0 4px 10px 0 rgba(0,0,0,0.10)',
        opacity: 0,
        transition: 'all 0.2s ease-out',
        pointerEvents: 'none',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
      },
      '.sc_header.show': {
        opacity: 1,
        top: '64px',
        pointerEvents: 'visible',
      },
      '.mdlmenu': {
        margin: '0 0 15px auto',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        paddingRight: '20px',
      },
      '.clm_box': {
        marginBottom: '15px',
      },
      '.mdlmenu a': {
        margin: '10px 0',
      },
    },
    '@media screen and (max-width: 767px)': {
      '.becom_far': {
        padding: '0 0 20px 0',
      },
      '.becm_fr p': {
        font: 'normal normal 300 16px/26px Kanit',
      },
      '.def_h': {
        fontSize: '30px !important',
        lineHeight: '35px !important',
      },
      '.def_p': {
        font: 'normal normal 300 16px/23px Kanit !important',
      },
      '.avx_bxc button': {
        fontSize: '14px',
        lineHeight: '16px',
      },
      '.plcb_bx': {
        display: 'block',
      },
      '.plcb_bx h4': {
        marginBottom: '15px',
      },
      '.csm_src_v2 button': {
        marginLeft: '0',
      },
      '.dtl_tp_bx': {
        paddingTop: '65px',
      },
      '.back_ic': {
        color: theme.palette.common.white,
        background: theme.palette.primary.main,
      },
      '.tab_ttl': {
        marginBottom: '10px',
        textAlign: 'center',
      },
    },
    '@media screen and (max-width: 599px)': {
      '.lstng_itmsldr .slick-prev': {
        left: 0,
        zIndex: 9,
      },
      '.lstng_itmsldr .slick-next': {
        right: 0,
        zIndex: 9,
      },
    },
    '@media screen and (max-width: 575px)': {
      '.accordidn_main': {
        padding: '25px 0',
      },
      '.accordidn_main .accodid_hed': {
        font: 'normal normal 600 18px/20px Kanit !important',
      },
      '.accordidn_main p': {
        font: 'normal normal 400 14px/18px Kanit !important',
      },
      '.partY_ranking_main': {
        padding: '30px 0',
      },
      '.party_left_img': {
        padding: '20px 10px 0 10px',
      },
      '.partY_ranking_main .css-h51dfx-MuiGrid-root>.MuiGrid-item': {
        paddingTop: '10px',
      },
      '.about_td_main': {
        padding: '40px 0',
      },
      '.about_td_main .css-iieaes-MuiGrid-root>.MuiGrid-item': {
        paddingTop: '0 !important',
      },
      '.abt_td_pddngh': {
        paddingLeft: '0px',
        marginTop: '15px',
      },
      '.becom_far .css-h51dfx-MuiGrid-root>.MuiGrid-item': {
        paddingTop: '0 !important',
      },
      '.becm_fr p': {
        font: 'normal normal 300 15px/22px Kanit',
      },
      '.abt_farmer': {
        minHeight: 'inherit',
      },
      '.td_contant': {
        paddingTop: '10px',
      },
      '.avx_bxc': {
        marginTop: '15px',
      },
      '.avx_bxc button': {
        marginTop: '10px',
        fontSize: '12px',
        lineHeight: '14px',
      },
      '.bnr_cntnt': {
        top: '70px',
      },
      '.def_h': {
        fontSize: '21px !important',
        lineHeight: '28px !important',
      },
      '.def_p': {
        font: 'normal normal 300 15px/22px Kanit !important',
      },
      '.d_b_575': {
        display: 'block',
      },
      '.back_ic_v2': {
        maxWidth: '92px',
      },
      '.avtr_rspnsv': {
        width: '30px',
        height: '30px',
      },
      '.defbtn_rspv span': {
        fontSize: '11px',
      },
      '.eco_mn h2, .sco_info h3': { fontSize: '32px' },
      '.sco_info p': { fontSize: '15px' },
      '.ecctble table tbody td': { fontSize: '15px' },
      '.sco_info': {
        padding: '15px 10px',
      },
      '.qntt_btntxt': {
        marginBottom: '20px !important',
        fontSize: '14px !important',
      },
      '.qntt_box': {
        width: '160px',
      },
      '.rdmp_box p': {
        fontSize: '15px',
      },
      '.rdmp_md_3': {
        maxWidth: '50%',
        flexBasis: '50%',
      },
      '.sc_header': {
        padding: '10px',
      },
      '.clm_box h4': {
        fontSize: '11px',
      },
      '.mdlmenu': { paddingRight: '0' },
      '.main_ratity': {
        padding: '40px 0',
      },
      '.main_ratity .graph_p': {
        padding: '20px 15px',
      },
      '.main_ratity .graph_p p': {
        fontSize: '15px',
      },
    },
    '@media screen and (max-width: 360px)': {
      '.defbtn_rspv': {
        padding: '5px 4px',
      },
    },
    '@media screen and (min-width: 576px)': {
      '.harvestButton': { marginTop: '-90px !important' },
    },
    '.ecoNFTCountdown': {
      display: 'flex',
      left: 'auto',
      top: '20px',
      right: '30px',
      alignItems: 'center',
      fontSize: '16px',
      position: 'absolute',
      color: '#3BB78F',
      fontFamily: 'Montserrat',
      fontWeight: '600',
    },
    // '@media screen and (max-width: 470px)': {
    //   '.clm_box h4' :{
    //     padding: '0 5px ',
    //     fontSize: '9px',
    //   },
    //   '.clm_box button':{
    //     minWidth: 'auto',
    //   },
    // },
    // '@media screen and (max-width: 399px)': {
    //   '.clm_box' :{
    //     display: 'none',
    //   },
    // },
  },
}))(() => null);

export default GlobalStyles;
