import React from 'react';
import getRpcUrl from 'utils/getRpcUrl';
import * as bsc from '@binance-chain/bsc-use-wallet';
import { HelmetProvider } from 'react-helmet-async';
import { Provider as ReduxProvider } from 'react-redux';
import { PersistGate } from 'redux-persist/lib/integration/react';
// material
import AdapterDateFns from '@material-ui/lab/AdapterDateFns';
import LocalizationProvider from '@material-ui/lab/LocalizationProvider';
// redux
import { store, persistor } from './redux/store';
// contexts
import { SettingsProvider } from './contexts/SettingsContext';
// components
import LoadingScreen from './components/LoadingScreen';
import { ModalProvider } from 'hooks/Modal';
import NotistackProvider from './components/NotistackProvider';
import { MoralisProvider } from 'react-moralis';

const Providers: React.FC = ({ children }) => {
  const rpcUrl: string = getRpcUrl();
  const chainId = parseInt(process.env.REACT_APP_CHAIN_ID!, 10);
  const appId = process.env.REACT_APP_MORALIS_APPLICATION_ID;
  const serverURL = process.env.REACT_APP_MORALIS_SERVER_URL;

  return (
    <HelmetProvider>
      <MoralisProvider appId={appId} serverUrl={serverURL}>
        <ReduxProvider store={store}>
          <PersistGate loading={<LoadingScreen />} persistor={persistor}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <SettingsProvider>
                <bsc.UseWalletProvider
                  chainId={chainId}
                  connectors={{
                    walletconnect: { rpcUrl },
                    bsc,
                  }}
                >
                  <ModalProvider>
                    <NotistackProvider>{children}</NotistackProvider>
                  </ModalProvider>
                </bsc.UseWalletProvider>
              </SettingsProvider>
            </LocalizationProvider>
          </PersistGate>
        </ReduxProvider>
      </MoralisProvider>
    </HelmetProvider>
  );
};

export default Providers;
