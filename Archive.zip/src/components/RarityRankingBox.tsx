import React from 'react';
import {
  Grid,
  Box,
  Container,
  Typography,
  Stack,
  Button,
} from '@material-ui/core';
import LinearProgress from '@material-ui/core/LinearProgress';

export default function RarityRankingBox({ farmerData }) {
  return (
    <>
      <Box className='farmer_box'>
        <Box component='img' src={farmerData.image} />
        <Box className='farmer_666'>
          <Typography component='h5'>{farmerData.name}</Typography>
          {/* <Box
            component='img'
            src='/static/images/apply.png'
            className='img_apply'
          /> */}
        </Box>
        <Box className='prgrss_main_box'>
          <Box className='head_pgrss'>
            <Typography>Eyes</Typography>
            <Box className='def_prgrss'>
              <LinearProgress
                variant='determinate'
                value={
                  farmerData.attributes[2].points +
                    farmerData.attributes[6].points >
                  1
                    ? 100
                    : 0
                }
              />
              <LinearProgress
                variant='determinate'
                value={
                  farmerData.attributes[2].points +
                    farmerData.attributes[6].points >
                  2
                    ? 100
                    : 0
                }
              />
              <LinearProgress
                variant='determinate'
                value={
                  farmerData.attributes[2].points +
                    farmerData.attributes[6].points >
                  3
                    ? 100
                    : 0
                }
              />
              <LinearProgress
                variant='determinate'
                value={
                  farmerData.attributes[2].points +
                    farmerData.attributes[6].points >
                  4
                    ? 100
                    : 0
                }
              />
              <LinearProgress
                variant='determinate'
                value={
                  farmerData.attributes[2].points +
                    farmerData.attributes[6].points >
                  5
                    ? 100
                    : 0
                }
              />
            </Box>
          </Box>
          <Box className='head_pgrss'>
            <Typography>HairHat</Typography>
            <Box className='def_prgrss'>
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[3].points > 1 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[3].points > 2 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[3].points > 3 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[3].points > 4 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[3].points > 5 ? 100 : 0}
              />
            </Box>
          </Box>
          <Box className='head_pgrss'>
            <Typography>Mouth</Typography>
            <Box className='def_prgrss'>
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[4].points > 1 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[4].points > 2 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[4].points > 3 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[4].points > 4 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[4].points > 5 ? 100 : 0}
              />
            </Box>
          </Box>
          <Box className='head_pgrss'>
            <Typography>Beard</Typography>
            <Box className='def_prgrss'>
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[5].points > 1 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[5].points > 2 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[5].points > 3 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[5].points > 4 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[5].points > 5 ? 100 : 0}
              />
            </Box>
          </Box>
          <Box className='head_pgrss'>
            <Typography>Clothes</Typography>
            <Box className='def_prgrss'>
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[7].points > 1 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[7].points > 2 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[7].points > 3 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[7].points > 4 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[7].points > 5 ? 100 : 0}
              />
            </Box>
          </Box>
          <Box className='head_pgrss'>
            <Typography>Objects</Typography>
            <Box className='def_prgrss'>
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[8].points > 1 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[8].points > 2 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[8].points > 3 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[8].points > 4 ? 100 : 0}
              />
              <LinearProgress
                variant='determinate'
                value={farmerData.attributes[8].points > 5 ? 100 : 0}
              />
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
}
