import { Button, Box } from '@material-ui/core';
import { useMoralis } from 'react-moralis';
import { networkSetup } from 'utils/networkSetup';
import { localStorageKey } from './config';
const Moralis = require('moralis');

const WalletCard = ({ login, walletConfig, onDismiss }: any) => {
  const { title, icon } = walletConfig;
  const currentChainId = parseInt(process.env.REACT_APP_CHAIN_ID, 10);
  const { authenticate } = useMoralis();

  //

  return (
    <Button
      fullWidth
      onClick={() => {
        if (Boolean(true)) {
          networkSetup(currentChainId)
            .then(async () => {
              login(walletConfig.connectorId);
              window.localStorage.setItem(localStorageKey, '1');
              onDismiss();
            })
            .catch((e) => {
              onDismiss();
              console.error(e);
            });
        }
      }}
      style={{ justifyContent: 'space-between' }}
      id={`wallet-connect-${title.toLocaleLowerCase()}`}
      className='mdl_c_btn'
    >
      {title}

      <Box component='img' alt={''} src={icon} height='30px' />
    </Button>
  );
};

export default WalletCard;
