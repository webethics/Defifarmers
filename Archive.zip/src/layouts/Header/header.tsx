import { useEffect, useState } from 'react';
import { Icon } from '@iconify/react';
import menu2Fill from '@iconify/icons-eva/arrowhead-right-outline';
import menu2FillLeft from '@iconify/icons-eva/arrowhead-left-outline';

// material
import { alpha, experimentalStyled as styled } from '@material-ui/core/styles';
import {
  Box,
  Button,
  Stack,
  AppBar,
  Toolbar,
  IconButton,
  Typography,
} from '@material-ui/core';
// components
import { useWallet } from '@binance-chain/bsc-use-wallet';
import AccountPopover from './Account';
import Connect from './Connect';
import Logo from 'components/Logo';
import LogoSmall from 'components/LogoSmall';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'redux/store';

import { ProductState } from '../../@types/products';
import useWeb3 from 'hooks/useWeb3';
import useWalletModal from './Wallet/useWalletModal';
import { Link } from 'react-scroll';
import MenuIcon from '@material-ui/icons/Menu';
import { useMysteryBoxAvax } from 'hooks/useContract';
import { useSnackbar } from 'notistack';
// ----------------------------------------------------------------------

const APPBAR_MOBILE = 64;
const APPBAR_DESKTOP = 70;
const optionsCursorTrueWithMargin = {
  followCursor: true,
  shiftX: 0,
  shiftY: 10,
};

const RootStyle = styled(AppBar)(({ theme }) => ({
  zIndex: 9999,
  boxShadow: 'none',
  backdropFilter: 'inherit',
  WebkitBackdropFilter: 'inherit',
  borderBottom: '1px solid',
  borderColor: theme.palette.grey[200],
  backgroundColor: alpha(theme.palette.background.default, 1),
  // [theme.breakpoints.up("lg")]: {
  //   width: `calc(100% - ${DRAWER_WIDTH + 1}px)`,
  // },
}));

const ToolbarStyle = styled(Toolbar)(({ theme }) => ({
  minHeight: APPBAR_MOBILE,
  [theme.breakpoints.up('lg')]: {
    minHeight: APPBAR_DESKTOP,
    padding: theme.spacing(0, 5),
  },
}));

// ----------------------------------------------------------------------

type HeaderProps = {
  onOpenSidebar: VoidFunction;
};

export default function Header({ onOpenSidebar }: HeaderProps) {
  const { account, connect, reset, chainId } = useWallet();
  const [isOpen, setIsOpen] = useState(false);
  const { pathname } = useLocation();
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();
  const [loading, setLoading] = useState(false);
  const mystryBoxContract = useMysteryBoxAvax();
  const [reward, setReward] = useState(0);
  const dispatch = useDispatch();
  const { accountAddress, myCollection } = useSelector(
    (state: { product: ProductState }) => state.product
  );

  const web3 = useWeb3();
  const { onPresentChainModal } = useWalletModal(connect, reset, account);

  useEffect(() => {
    document.body.classList.toggle('sidebar-open', isOpen);
  }, [isOpen]);
  //for menu
  const [isActive, setActive] = useState(false);

  const toggleClass = () => {
    setActive(!isActive);
  };

  useEffect(() => {
    const getData = async () => {
      const getReflectionBalance = await mystryBoxContract.methods
        .getReflectionBalances()
        .call({ from: account });
      setReward(Number((getReflectionBalance / 1e18).toFixed(5)));
    };
    if (account) {
      getData();
    }
  }, [account]);

  const claimReward = async () => {
    if (account) {
      let snackKey;
      await mystryBoxContract.methods
        .claimRewards()
        .send({ from: account })
        .once('transactionHash', (transactionHash) => {
          snackKey = enqueueSnackbar('Reward Claiming is in Progress', {
            variant: 'info',
            preventDuplicate: true,
            persist: true,
          });
        })
        .once('confirmation', (confirmation) => {
          closeSnackbar(snackKey);
          setLoading(false);
          enqueueSnackbar('Reward claimed Successfully', {
            variant: 'info',
          });
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        })
        .on('error', (error) => {
          closeSnackbar(snackKey);

          setLoading(false);
          enqueueSnackbar('Error while claiming Reward', {
            variant: 'error',
          });
        });
    } else {
      alert('Please Connect Wallet');
    }
  };
  return (
    <RootStyle>
      <ToolbarStyle>
        <Box sx={{ marginLeft: '0px', marginRight: 'auto' }}>
          <Box className='d_logo'>
            <a href='https://app.treedefi.com'>
              <Logo />
            </a>
          </Box>
          <Box className='m_logo'>
            <a href='https://app.treedefi.com'>
              <LogoSmall />
            </a>
          </Box>
        </Box>
        {/* {pathname === '/' && (
          <IconButton
            onClick={() => setIsOpen(!isOpen)}
            sx={{
              mr: '15px',
              color: 'primary.mlight',
              fontSize: 14,
              border: 1,
              borderColor: 'primary.mlight',
              p: '10px',
              ml: '10px',
            }}
          >
            <Icon icon={isOpen ? menu2Fill : menu2FillLeft} />
          </IconButton>
        )} */}

        {/* <Box sx={{ flexGrow: 1 }} /> */}

        <Button onClick={toggleClass} className='mnicon_btn'>
          <MenuIcon />
        </Button>
        <Box className={isActive ? 'show sc_header' : 'sc_header'}>
          <Box className='mdlmenu'>
            <Link
              to='FeaturesSc'
              activeClass='active'
              spy={true}
              smooth={true}
              offset={-50}
              duration={500}
            >
              About
            </Link>
            <Link
              to='MintSc'
              spy={true}
              smooth={true}
              offset={-50}
              duration={500}
            >
              Mint
            </Link>
            <Link
              to='RaritySc'
              spy={true}
              smooth={true}
              offset={-50}
              duration={500}
            >
              Rarity
            </Link>
            <Link
              to='RoadmapSc'
              spy={true}
              smooth={true}
              offset={-50}
              duration={500}
            >
              Roadmap
            </Link>
            <Link
              to='ClaimSc'
              spy={true}
              smooth={true}
              offset={-50}
              duration={500}
            >
              Faq
            </Link>
          </Box>
          <Box className='clm_box'>
            <Typography component='h4'>Rewards: {reward}</Typography>
            <Button
              variant='contained'
              color='primary'
              className='defbtn defbtn_rspv'
              onClick={claimReward}
              disabled={reward <= 0}
            >
              Claim
            </Button>
          </Box>

          <Stack direction='row' spacing={{ xs: 0.5, sm: 1.5 }}>
          <Button
              variant='contained'
              color='primary'
              className='defbtn defbtn_rspv'
              sx={{ textTransform: 'uppercase' }}
              // onClick={() => {
              //   onPresentChainModal();
              // }}
            >
              My farmers
            </Button>
            <Button
              variant='contained'
              color='primary'
              className='defbtn defbtn_rspv'
              sx={{ textTransform: 'uppercase' }}
              // onClick={() => {
              //   onPresentChainModal();
              // }}
            >
              <Box
                component='img'
                alt={''}
                src={'/static/icons/networks/avax.jpg'}
                height='20px'
                sx={{ pr: 1 }}
              />
              {'  '}
              {'  Avalanche'}
            </Button>
            {account && <AccountPopover account={account} logout={reset} />}
            {!account && (
              <Connect account={account} login={connect} logout={reset} />
            )}
          </Stack>
        </Box>
      </ToolbarStyle>
    </RootStyle>
  );
}
