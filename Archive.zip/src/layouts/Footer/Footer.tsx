import twitterFill from "@iconify/icons-eva/twitter-fill";
import telegramIcon from "@iconify/icons-simple-icons/telegram";
import youtubeIcon from "@iconify/icons-simple-icons/youtube";
// npm install --save-dev @iconify/react @iconify-icons/ant-design
import mediumSquareFilled from "@iconify/icons-ant-design/medium-square-filled";

import { Link as ScrollLink } from "react-scroll";
// material
import { experimentalStyled as styled } from "@material-ui/core/styles";
import {
  Grid,
  Link,
  Divider,
  Container,
  Typography,
  Stack,
} from "@material-ui/core";
//
import Logo from "../../components/Logo";

// ----------------------------------------------------------------------

const LINKS = [
  {
    headline: "Eco System",
    children: [
      { name: "Homepage", href: "https://treedefi.com" },
      { name: "Yield Farming", href: "https://app.treedefi.com" },
      { name: "Exchange", href: "https://exchange.treedefi.com" },
      { name: "Merchandising", href: "https://app.treedefi.com/#/merchandise" },
      { name: "Donation", href: "https://app.treedefi.com/#/donation" },
    ],
  },
  {
    headline: "Community",
    children: [
      { name: "TeleGram", icon: telegramIcon, href: "https://t.me/treedefi" },
      {
        name: "Twitter",
        icon: twitterFill,
        href: "https://twitter.com/treedefi",
      },
      {
        name: "Youtube",
        icon: youtubeIcon,
        href: "https://youtube.com/user/treedefi",
      },
      {
        name: "Medium",
        icon: mediumSquareFilled,
        href: "https://news.treedefi.com",
      },
    ],
  },

  {
    headline: "Contact",
    children: [
      { name: "Feedback", href: "https://feedback.treedefi.com" },
      { name: "Status", href: "http://status.treedefi.com/" },
      {
        name: "Documentation",
        href: "https://docs.treedefi.info/collectibles",
      },
    ],
  },
];

const RootStyle = styled("div")(({ theme }) => ({
  position: "relative",
  backgroundColor: theme.palette.background.default,
}));

// ----------------------------------------------------------------------

export default function Footer() {
  return (
    <RootStyle>
      <Divider />
      <Container maxWidth="lg" sx={{ pt: 10 }}>
        <Grid
          container
          justifyContent={{ xs: "center", md: "space-between" }}
          sx={{ textAlign: { xs: "center", md: "left" } }}
        >
          <Grid item xs={12} sx={{ mb: 3 }}>
            <ScrollLink to="move_top" spy smooth>
              <Logo sx={{ mx: { xs: "auto", md: "inherit" } }} />
            </ScrollLink>
          </Grid>
          <Grid item xs={8} md={3}>
            <Typography variant="body2" sx={{ pr: { md: 5 } }}>
              Treedefi is the first ecofriendly defi project. We are fighting carbon emission by creating a
              thriving ecosystem focused on NFT and carbon credit tokens. Now expanding in AVAX ecosystem
            </Typography>
          </Grid>

          <Grid item xs={12} md={7}>
            <Stack
              spacing={5}
              direction={{ xs: "column", md: "row" }}
              justifyContent="space-between"
            >
              {LINKS.map((list) => {
                const { headline, children } = list;
                return (
                  <Stack key={headline} spacing={2}>
                    <Typography component="p" variant="overline">
                      {headline}
                    </Typography>
                    {children.map((link) => (
                      <Link
                        href={link.href}
                        target="_blank"
                        key={link.name}
                        color="inherit"
                        variant="body2"
                        // component={RouterLink}
                        sx={{ display: "block" }}
                      >
                        {link.name}
                      </Link>
                    ))}
                  </Stack>
                );
              })}
            </Stack>
          </Grid>
        </Grid>

        <Typography
          component="p"
          variant="body2"
          sx={{
            mt: 10,
            pb: 5,
            fontSize: 13,
            textAlign: { xs: "center", md: "left" },
          }}
        >
          © 2021. All rights reserved
        </Typography>
      </Container>
    </RootStyle>
  );
}
